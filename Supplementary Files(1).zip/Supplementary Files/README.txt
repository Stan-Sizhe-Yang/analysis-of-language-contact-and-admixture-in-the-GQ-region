Folder "1.PCA/" contains an R script and its corresponding input RData for PCA.
Folder "2.Neighbor-net and delta scores/Delta Score" contains 3 nexus files as input of SplitsTree, an R script and its input RData to do analysis related to Delta Score.
Folder "2.Neighbor-net and delta scores/Neighbor-net" contains an R script and its input RData to perform neighbor-net analysis.
Folder "3.F3" contains R code and RData files to caculate F3.
Folder "4.Bayesian network" contains an R script and RData to infer Bayesian networks.
Folder "5.TSTest" contains R functions needed to run TS-Test, R codes to replicate results in this study, and its corresponding RData.
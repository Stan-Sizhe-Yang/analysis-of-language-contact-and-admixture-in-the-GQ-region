#+eval=FALSE

library(dplyr)
library(bnlearn)

load("path/to/Data.BN.RData")
### Network
score <- "pnal-g"
## Phonology
bn.Pho <- hc(Pho_freq, score = score);  plot(bn.Pho, main = paste0("Pho_", score))
bn.Pho.strength <- arc.strength(bn.Pho, data = Pho_freq)
bn.Pho.score <- score(bn.Pho, data = Pho_freq); bn.Pho.score
bn.Pho.strength.proportion <- bn.Pho.strength %>% mutate(proportion = abs(strength/bn.Pho.score)); bn.Pho.strength.proportion
bn.Pho.strength.plot <- strength.plot(bn.Pho, bn.Pho.strength, shape = "circle", main = paste0("Pho_", score), fontsize = 6.5); bn.Pho.strength.plot
## Morpho-syntax
bn.Syn <- hc(Syn_freq, score = score);  plot(bn.Syn, main = paste0("Mor-Syn_", score))
bn.Syn.strength <- arc.strength(bn.Syn, data = Syn_freq)
bn.Syn.score <- score(bn.Syn, data = Syn_freq); bn.Syn.score
bn.Syn.strength.proportion <- bn.Syn.strength %>% mutate(proportion = abs(strength/bn.Syn.score)); bn.Syn.strength.proportion
bn.Syn.strength.plot <- strength.plot(bn.Syn, bn.Syn.strength, shape = "circle", main = paste0("Mor-Syn_", score), fontsize = 6.5); bn.Syn.strength.plot
## Overall
bn.Com <- hc(Com_freq, score = score);  plot(bn.Com, main = paste0("Overall_", score))
bn.Com.strength <- arc.strength(bn.Com, data = Com_freq)
bn.Com.score <- score(bn.Com, data = Com_freq); bn.Com.score
bn.Com.strength.proportion <- bn.Com.strength %>% mutate(proportion = abs(strength/bn.Com.score)); bn.Com.strength.proportion
bn.Com.strength.plot <- strength.plot(bn.Com, bn.Com.strength, shape = "circle", main = paste0("Overall_", score), fontsize = 6.5); bn.Com.strength.plot
#+eval=FALSE

F3 <- function(data, data.group, sig.test = F, boot.n = 500){
  group.dat <- data.frame(Group = data.group, data)
  ####### F3 ##############
  freq.dat <- group.dat %>% group_by(Group) %>% summarise_all(.funs = function(i)mean(i, na.rm = T))
  group <- freq.dat$Group
  dat <- freq.dat[,-1]
  F3.func <- function(dat, group){
    dat.group <- tibble(dat, group = group)
    f3.func <- function(l1, l2, l3){
      v1 <- dat.group %>% filter(group == l1) %>% dplyr::select(-c('group')) %>% as.matrix() %>% as.vector()
      v2 <- dat.group %>% filter(group == l2) %>% dplyr::select(-c('group')) %>% as.matrix() %>% as.vector()
      v3 <- dat.group %>% filter(group == l3) %>% dplyr::select(-c('group')) %>% as.matrix() %>% as.vector()
      f3 <- t(v1-v2) %*% (v1-v3) /ncol(dat) %>% as.vector()
      return(f3)
    }
    label <- as_tibble(expand.grid(group, group, group)) %>% filter(!(Var1 == Var2 | Var1 == Var3 | Var2 == Var3)) %>% as.matrix()
    f3.mat <- data.frame(label, f3 = apply(label, 1, function(i){
      f3.func(i[1], i[2], i[3])
    })) %>% as_tibble()
  }
  F3.mat <- F3.func(dat, group)
  if (sig.test == T) {
    set.seed(1)
    F3.mat.boot.list <- lapply(1:boot.n, function(i){
      freq.dat.boot <- group.dat %>% group_by(Group) %>% 
        transmute_all(.funs = function(i) sample(i, length(i), replace = T)) %>%
        summarise_all(.funs = function(i)mean(i, na.rm = T))
      dat.boot <- freq.dat.boot[,-1]
      F3.mat <- F3.func(dat.boot, group)
    })
    F3.mat.boot <- data.frame(F3.mat.boot.list[[1]][,1:3], do.call('cbind', lapply(F3.mat.boot.list, function(i) i$f3))) %>% as_tibble()
    mean.sd.vec <- do.call('rbind',lapply(1:nrow(F3.mat.boot[,-c(1:3)]), function(i){
      f3.boot <- F3.mat.boot[i,-c(1:3)] %>% unlist()
      mean <- mean(f3.boot)
      sd <- sd(f3.boot)
      return(c(mean = mean, sd = sd))
    }))
    z.score <- (F3.mat$f3 - mean.sd.vec[,1])/mean.sd.vec[,2]
    p.value <- apply(F3.mat.boot[,-c(1:3)], 1, function(i) sum(i > 0)/length(i))
    F3.mat <- data.frame(F3.mat, z.score = z.score, p.value = p.value) %>% as_tibble()
    print(F3.mat)
    admixture.direc <- matrix(0, nrow = length((group)), ncol = length((group)))
    colnames(admixture.direc) <- rownames(admixture.direc) <- (group)
    for (i in 1:nrow(F3.mat)){
      if (unlist(F3.mat[i,'f3']) < 0 & unlist(F3.mat[i,'p.value']) < 0.05){
        var1.name <- unlist(F3.mat[i,'Var1'])
        var2.name <- unlist(F3.mat[i,'Var2'])
        var3.name <- unlist(F3.mat[i,'Var3'])
        admixture.direc[c(var2.name, var3.name),var1.name] <- 1
      }
    }
    plot(graph_from_adjacency_matrix(admixture.direc))
    
    return(list(F3.mat.boot = F3.mat.boot, F3.mat = F3.mat, freq.dat = freq.dat, group.dat = group.dat, admixture.direc = admixture.direc))
  }
  else{
    admixture.direc <- matrix(0, nrow = length((group)), ncol = length((group)))
    colnames(admixture.direc) <- rownames(admixture.direc) <- (group)
    for (i in 1:nrow(F3.mat)){
      if (unlist(F3.mat[i,'f3']) < 0){
        var1.name <- unlist(F3.mat[i,'Var1'])
        var2.name <- unlist(F3.mat[i,'Var2'])
        var3.name <- unlist(F3.mat[i,'Var3'])
        admixture.direc[c(var2.name, var3.name),var1.name] <- 1
      }
    }
    plot(graph_from_adjacency_matrix(admixture.direc))
    return(list(F3.mat = F3.mat, freq.dat = freq.dat, group.dat = group.dat, admixture.direc = admixture.direc))
  }
}

F3.boot <- function(data, data.group, boot.n = 500){
  group.dat <- data.frame(Group = data.group, data)
  freq.dat <- group.dat %>% group_by(Group) %>% summarise_all(.funs = function(i)mean(i, na.rm = T))
  group <- freq.dat$Group
  dat <- freq.dat[,-1]
  F3.func <- function(dat, group){
    dat.group <- tibble(dat, group = group)
    f3.func <- function(l1, l2, l3){
      v1 <- dat.group %>% filter(group == l1) %>% dplyr::select(-c('group')) %>% as.matrix() %>% as.vector()
      v2 <- dat.group %>% filter(group == l2) %>% dplyr::select(-c('group')) %>% as.matrix() %>% as.vector()
      v3 <- dat.group %>% filter(group == l3) %>% dplyr::select(-c('group')) %>% as.matrix() %>% as.vector()
      f3 <- t(v1-v2) %*% (v1-v3) /ncol(dat) %>% as.vector()
      return(f3)
    }
    label <- as_tibble(expand.grid(group, group, group)) %>% filter(!(Var1 == Var2 | Var1 == Var3 | Var2 == Var3)) %>% as.matrix()
    f3.mat <- data.frame(label, f3 = apply(label, 1, function(i){
      f3.func(i[1], i[2], i[3])
    })) %>% as_tibble()
  }
  set.seed(1)
  F3.mat.boot.list <- lapply(1:boot.n, function(i){
    freq.dat.boot <- group.dat %>% group_by(Group) %>% 
      transmute_all(.funs = function(i) sample(i, length(i), replace = T)) %>%
      summarise_all(.funs = function(i)mean(i, na.rm = T))
    dat.boot <- freq.dat.boot[,-1]
    F3.mat <- F3.func(dat.boot, group)
  })
  F3.mat.boot <- data.frame(F3.mat.boot.list[[1]][,1:3], do.call('cbind', lapply(F3.mat.boot.list, function(i) i$f3))) %>% as_tibble()
  return(F3.mat.boot)
}

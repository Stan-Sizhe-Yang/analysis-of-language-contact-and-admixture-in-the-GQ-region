#+eval=FALSE

library(dplyr)
library(VIM)
library(factoextra)
library(ggplot2)
library(ggrepel)


load("path/to/1.PCA/Data.PCA.RData")
### Impute
GQ.Pho.Imputed <- GQ.Pho %>% .[, apply(., 2, function(x) length(unique(x)) > 1)] # No missing values
GQ.Syn.Imputed <- kNN(GQ.Syn)[1:ncol(GQ.Syn)] %>% .[, apply(., 2, function(x) length(unique(x)) > 1)]
GQ.Com.Imputed <- kNN(GQ.Com)[1:ncol(GQ.Com)] %>% .[, apply(., 2, function(x) length(unique(x)) > 1)]
### PCA
GQ.Pho.PCA.Res <- prcomp(GQ.Pho.Imputed[-1])
GQ.Syn.PCA.Res <- prcomp(GQ.Syn.Imputed[-1])
GQ.Com.PCA.Res <- prcomp(GQ.Com.Imputed[-1])
### Scree Plot
fviz_eig(GQ.Pho.PCA.Res, addlabels = TRUE, main = "Phonology")
fviz_eig(GQ.Syn.PCA.Res, addlabels = TRUE, main = "Morpho-syntax")
fviz_eig(GQ.Com.PCA.Res, addlabels = TRUE, main = "Overall")
### Generate data for plotting
plot.data.Pho <- data.frame(name = names, 
                            group = group) %>% cbind(., GQ.Pho.PCA.Res$x)
plot.data.Syn <- data.frame(name = names, 
                            group = group) %>% cbind(., GQ.Syn.PCA.Res$x)
plot.data.Com <- data.frame(name = names, 
                            group = group) %>% cbind(., GQ.Com.PCA.Res$x)
### Plot
### Pho
plot.Pho <- ggplot() + 
  geom_point(data = plot.data.Pho[plot.data.Pho$group %in% c("Sn", "GQSn"), ], aes(x = PC1, y = PC2), colour = "#A2635A", size = 5, pch = (1:nrow(plot.data.Pho[plot.data.Pho$group %in% c("Sn", "GQSn"), ])), stroke = 1) +
  geom_point(data = plot.data.Pho[plot.data.Pho$group %in% c("Tb", "GQTb"), ], aes(x = PC1, y = PC2), colour = "gray30", size = 5, pch = (1:nrow(plot.data.Pho[plot.data.Pho$group %in% c("Tb", "GQTb"), ])), stroke = 1) +
  geom_point(data = plot.data.Pho[plot.data.Pho$group %in% c("Mn", "GQMn"), ], aes(x = PC1, y = PC2), colour = "#5F7A99", size = 5, pch = (1:nrow(plot.data.Pho[plot.data.Pho$group %in% c("Mn", "GQMn"), ])), stroke = 1) +
  geom_point(data = plot.data.Pho[plot.data.Pho$group %in% c("Tk", "GQTk"), ], aes(x = PC1, y = PC2), colour = "#B89B5A", size = 5, pch = (1:nrow(plot.data.Pho[plot.data.Pho$group %in% c("Tk", "GQTk"), ])), stroke = 1) +
  geom_label_repel(data = plot.data.Pho[plot.data.Pho$group %in% c("Tn", "GQMn", "Mn", "Tb", "GQTb", "Tk", "GQTk", "Sn", "GQSn"), ], aes(x = PC1, y = PC2, label = name), size = 2) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.ticks = element_blank(),
        axis.text.x = element_text(color = "black"),
        axis.text.y = element_text(color = "black"),
        axis.title.x = element_text(size = 9),
        axis.title.y = element_text(size = 9),
        panel.background = element_rect(fill = "white"),
        panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  labs(x = "Principle component 1", y = "Principle component 2") +
  ggtitle("Phonology")
plot.Pho
### Syn
plot.Syn <- ggplot() + 
  geom_point(data = plot.data.Syn[plot.data.Syn$group %in% c("Sn", "GQSn"), ], aes(x = PC1, y = PC2), colour = "#A2635A", size = 5, pch = (1:nrow(plot.data.Syn[plot.data.Syn$group %in% c("Sn", "GQSn"), ])), stroke = 1) +
  geom_point(data = plot.data.Syn[plot.data.Syn$group %in% c("Tb", "GQTb"), ], aes(x = PC1, y = PC2), colour = "gray30", size = 5, pch = (1:nrow(plot.data.Syn[plot.data.Syn$group %in% c("Tb", "GQTb"), ])), stroke = 1) +
  geom_point(data = plot.data.Syn[plot.data.Syn$group %in% c("Mn", "GQMn"), ], aes(x = PC1, y = PC2), colour = "#5F7A99", size = 5, pch = (1:nrow(plot.data.Syn[plot.data.Syn$group %in% c("Mn", "GQMn"), ])), stroke = 1) +
  geom_point(data = plot.data.Syn[plot.data.Syn$group %in% c("Tk", "GQTk"), ], aes(x = PC1, y = PC2), colour = "#B89B5A", size = 5, pch = (1:nrow(plot.data.Syn[plot.data.Syn$group %in% c("Tk", "GQTk"), ])), stroke = 1) +
  geom_label_repel(data = plot.data.Syn[plot.data.Syn$group %in% c("Tn", "GQMn", "Mn", "Tb", "GQTb", "Tk", "GQTk", "Sn", "GQSn"), ], aes(x = PC1, y = PC2, label = name), size = 2) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.ticks = element_blank(),
        axis.text.x = element_text(color = "black"),
        axis.text.y = element_text(color = "black"),
        axis.title.x = element_text(size = 9),
        axis.title.y = element_text(size = 9),
        panel.background = element_rect(fill = "white"),
        panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  labs(x = "Principle component 1", y = "Principle component 2") +
  ggtitle("Morpho-syntax")
plot.Syn
### Com
plot.Com <- ggplot() + 
  geom_point(data = plot.data.Com[plot.data.Com$group %in% c("Sn", "GQSn"), ], aes(x = PC1, y = PC2), colour = "#A2635A", size = 5, pch = (1:nrow(plot.data.Com[plot.data.Com$group %in% c("Sn", "GQSn"), ])), stroke = 1) +
  geom_point(data = plot.data.Com[plot.data.Com$group %in% c("Tb", "GQTb"), ], aes(x = PC1, y = PC2), colour = "gray30", size = 5, pch = (1:nrow(plot.data.Com[plot.data.Com$group %in% c("Tb", "GQTb"), ])), stroke = 1) +
  geom_point(data = plot.data.Com[plot.data.Com$group %in% c("Mn", "GQMn"), ], aes(x = PC1, y = PC2), colour = "#5F7A99", size = 5, pch = (1:nrow(plot.data.Com[plot.data.Com$group %in% c("Mn", "GQMn"), ])), stroke = 1) +
  geom_point(data = plot.data.Com[plot.data.Com$group %in% c("Tk", "GQTk"), ], aes(x = PC1, y = PC2), colour = "#B89B5A", size = 5, pch = (1:nrow(plot.data.Com[plot.data.Com$group %in% c("Tk", "GQTk"), ])), stroke = 1) +
  geom_label_repel(data = plot.data.Com[plot.data.Com$group %in% c("Tn", "GQMn", "Mn", "Tb", "GQTb", "Tk", "GQTk", "Sn", "GQSn"), ], aes(x = PC1, y = PC2, label = name), size = 2) +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.ticks = element_blank(),
        axis.text.x = element_text(color = "black"),
        axis.text.y = element_text(color = "black"),
        axis.title.x = element_text(size = 9),
        axis.title.y = element_text(size = 9),
        panel.background = element_rect(fill = "white"),
        panel.border = element_rect(colour = "black", fill = NA, size = 0.5)) +
  labs(x = "Principle component 1", y = "Principle component 2") +
  ggtitle("Overall")
plot.Com

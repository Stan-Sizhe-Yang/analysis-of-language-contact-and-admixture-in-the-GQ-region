#+eval=FALSE

load("path/to/Data.ds.RData")

### Mean and median delta scores
## Phonology
Pho.ds.nonGQ.mean <- mean(Pho.ds.nonGQ); print(paste0("Pho mean delta score of nonGQ: ", Pho.ds.nonGQ.mean))
Pho.ds.GQ.mean <- mean(Pho.ds.GQ); print(paste0("Pho mean delta score of GQ: ", Pho.ds.GQ.mean))
Pho.ds.nonGQ.median <- median(Pho.ds.nonGQ); print(paste0("Pho median delta score of nonGQ: ", Pho.ds.nonGQ.median))
Pho.ds.GQ.median <- median(Pho.ds.GQ); print(paste0("Pho median delta score of GQ: ", Pho.ds.GQ.median))
## Morpho-syntax
Syn.ds.nonGQ.mean <- mean(Syn.ds.nonGQ); print(paste0("Mor-Syn mean delta score of nonGQ: ", Syn.ds.nonGQ.mean))
Syn.ds.GQ.mean <- mean(Syn.ds.GQ); print(paste0("Mor-Syn mean delta score of GQ: ", Syn.ds.GQ.mean))
Syn.ds.nonGQ.median <- median(Syn.ds.nonGQ); print(paste0("Mor-Syn median delta score of nonGQ: ", Syn.ds.nonGQ.median))
Syn.ds.GQ.median <- median(Syn.ds.GQ); print(paste0("Mor-Syn median delta score of GQ: ", Syn.ds.GQ.median))
### Overall
Com.ds.nonGQ.mean <- mean(Com.ds.nonGQ); print(paste0("Overall mean delta score of nonGQ: ", Com.ds.nonGQ.mean))
Com.ds.GQ.mean <- mean(Com.ds.GQ); print(paste0("Overall mean delta score of GQ: ", Com.ds.GQ.mean))
Com.ds.nonGQ.median <- median(Com.ds.nonGQ); print(paste0("Overall median delta score of nonGQ: ", Com.ds.nonGQ.median))
Com.ds.GQ.median <- median(Com.ds.GQ); print(paste0("Overall median delta score of GQ: ", Com.ds.GQ.median))
### Test
## Phonology
Pho.test.result <- wilcox.test(Pho.ds.GQ, Pho.ds.nonGQ, alternative = "greater", paired = F); Pho.test.result
Pho.p.value <- Pho.test.result$p.value; Pho.p.value
## Morpho-syntax
Syn.test.result <- wilcox.test(Syn.ds.GQ, Syn.ds.nonGQ, alternative = "greater", paired = F); Syn.test.result
Syn.p.value <- Syn.test.result$p.value; Syn.p.value
## Overall
Com.test.result <- wilcox.test(Com.ds.GQ, Com.ds.nonGQ, alternative = "greater", paired = F); Com.test.result
Com.p.value <- Com.test.result$p.value; Com.p.value
### Plot
## Phonology
boxplot(Pho.ds.GQ, Pho.ds.nonGQ, names = c("GQ", "nonGQ"), ylim = c(0.2, 0.4), ylab = "Delta Score", main = "Phonology")
y_max <- max(c(Pho.ds.GQ, Pho.ds.nonGQ)) + 0.01
segments(x0 = 1, x1 = 2, y0 = y_max, y1 = y_max)
text(x = 1.5, y = max(c(Pho.ds.GQ, Pho.ds.nonGQ)) + 0.02, 
     labels = paste0("p = ", signif(Pho.p.value, digits = 3)), 
     cex = 1)
## Morpho-syntax
boxplot(Syn.ds.GQ, Syn.ds.nonGQ, names = c("GQ", "nonGQ"), ylim = c(0.2, 0.4), ylab = "Delta Score", main = "Morpho-syntax")
y_max <- max(c(Syn.ds.GQ, Syn.ds.nonGQ)) + 0.01
segments(x0 = 1, x1 = 2, y0 = y_max, y1 = y_max)
text(x = 1.5, y = max(c(Syn.ds.GQ, Syn.ds.nonGQ)) + 0.02, 
     labels = paste0("p = ", signif(Syn.p.value, digits = 3)), 
     cex = 1)
## Overall
boxplot(Com.ds.GQ, Com.ds.nonGQ, names = c("GQ", "nonGQ"), ylim = c(0.2, 0.4), ylab = "Delta Score", main = "Overall")
y_max <- max(c(Com.ds.GQ, Com.ds.nonGQ)) + 0.01
segments(x0 = 1, x1 = 2, y0 = y_max, y1 = y_max)
text(x = 1.5, y = max(c(Com.ds.GQ, Com.ds.nonGQ)) + 0.02, 
     labels = paste0("p = ", signif(Com.p.value, digits = 3)), 
     cex = 1)
### Correlation coefficients
## Spearman
spearman_result <- cor.test(Syn.ds.GQ, Pho.ds.GQ, method = "spearman"); spearman_result
## Kendall
kendall_result <- cor.test(Syn.ds.GQ, Pho.ds.GQ, method = "kendall"); kendall_result

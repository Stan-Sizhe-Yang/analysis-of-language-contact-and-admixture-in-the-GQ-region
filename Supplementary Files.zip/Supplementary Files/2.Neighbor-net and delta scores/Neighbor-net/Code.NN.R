#+eval=FALSE

library(phangorn)
library(dplyr)
library(grid)
library(gridGraphics)
library(vegan)

load("path/to/Data.NN.RData")

### Distances ###
### Hamming distances
hm.Pho <- dist.hamming(data.Pho)
hm.Syn <- dist.hamming(data.Syn)
hm.Com <- dist.hamming(data.Com)
### Neighbor-net ###
### NN Hamming
nnet.hm.Pho <- neighborNet(hm.Pho)
nnet.hm.Syn <- neighborNet(hm.Syn)
nnet.hm.Com <- neighborNet(hm.Com)
### Plot ###
### Define tip colors
color_match <- data.frame(Phylum = c("Sn", "Tb", "Mn", "Tk"),
                          Color = c("#A2635A", "black", "#5F7A99", "#B89B5A"))
tip_color.hm.Pho <- match(nnet.hm.Pho$tip.label, lang$Lang_Abbr) %>% lang$Phylum[.] %>% match(color_match$Phylum) %>% color_match$Color[.]
tip_color.hm.Syn <- match(nnet.hm.Syn$tip.label, lang$Lang_Abbr) %>% lang$Phylum[.] %>% match(color_match$Phylum) %>% color_match$Color[.]
tip_color.hm.Com <- match(nnet.hm.Com$tip.label, lang$Lang_Abbr) %>% lang$Phylum[.] %>% match(color_match$Phylum) %>% color_match$Color[.]
### Define a function to add scale bar
add_scale_bar <- function(x, y, length, label, offset = 0.02) {
  segments(x0 = x, y0 = y, x1 = x + length, y1 = y, lwd = 2, col = "black")
  text(
    x = x + length/2, 
    y = y + offset - 0.01, 
    labels = label, 
    cex = 0.8, 
    col = "black",
    pos = 1
  )
}
### Plot Hamming NN Phonology
plot(nnet.hm.Pho, tip.color = tip_color.hm.Pho, cex = 0.8, edge.width = 2, font = 2, edge.color = "black", title = "Phonology")
usr <- par("usr")
x_start <- usr[1] + 0.05 * (usr[2] - usr[1])
y_pos <- usr[3] + 0.05 * (usr[4] - usr[3])
add_scale_bar(x = x_start + 0.25, y = y_pos, length = 0.1, label = "0.1", offset = 0.01)
### Plot Hamming NN Morpho-syntax
plot(nnet.hm.Syn, tip.color = tip_color.hm.Syn, cex = 0.8, edge.width = 2, font = 2, edge.color = "black", main = "Morpho-Syntax")
usr <- par("usr")
x_start <- usr[1] + 0.05 * (usr[2] - usr[1])
y_pos <- usr[3] + 0.05 * (usr[4] - usr[3])
add_scale_bar(x = x_start + 0.45 , y = y_pos + 0.05, length = 0.1, label = "0.1", offset = 0.01)
### Plot Hamming NN Overall
plot(nnet.hm.Com, tip.color = tip_color.hm.Com, cex = 0.8, edge.width = 2, font = 2, edge.color = "black", title = "Overall")
usr <- par("usr")
x_start <- usr[1] + 0.05 * (usr[2] - usr[1])
y_pos <- usr[3] + 0.05 * (usr[4] - usr[3])
add_scale_bar(x = x_start + 0.45, y = y_pos + 0.05 , length = 0.1, label = "0.1", offset = 0.01)













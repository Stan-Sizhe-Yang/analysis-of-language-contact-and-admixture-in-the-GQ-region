#+eval=FALSE

library(dplyr)
library(VIM)
library(ggplot2)
library(igraph)
library(openxlsx)

### Load functions to calculate F3
source("path/to/Code.F3Function.R")
### Load data
load("path/to/Data.RunF3.RData")

### Impute
GQ_Pho_Imputed <- GQ_Pho %>% .[, apply(., 2, function(x) length(unique(x)) > 1)] # No missing values
GQ_Syn_Imputed <- kNN(GQ_Syn)[1:ncol(GQ_Syn)] %>% .[, apply(., 2, function(x) length(unique(x)) > 1)]
GQ_Com_Imputed <- kNN(GQ_Com)[1:ncol(GQ_Com)] %>% .[, apply(., 2, function(x) length(unique(x)) > 1)]
### F3
f3_Syn_GQ <- F3(data = GQ_Syn_Imputed[-1], data.group = label_GQ, sig.test = T)
f3_boot_Syn_GQ <- F3.boot(data = GQ_Syn_Imputed[-1], data.group = label_GQ)[-1:-3]
f3_Pho_GQ <- F3(data = GQ_Pho_Imputed[-1], data.group = label_GQ, sig.test = T)
f3_boot_Pho_GQ <- F3.boot(data = GQ_Pho_Imputed[-1], data.group = label_GQ)[-1:-3]
f3_Com_GQ <- F3(data = GQ_Com_Imputed[-1], data.group = label_GQ, sig.test = T)
f3_boot_Com_GQ <- F3.boot(data = GQ_Com_Imputed[-1], data.group = label_GQ)[-1:-3]
### Plot
plot_data_Syn <- data.frame(f3 = f3_Syn_GQ$F3.mat[3, "f3"]) 
plot_data_Pho <- data.frame(f3 = f3_Pho_GQ$F3.mat[3, "f3"]) 
plot_data_Com <- data.frame(f3 = f3_Com_GQ$F3.mat[3, "f3"]) 
plot_data <- rbind(plot_data_Pho, plot_data_Syn, plot_data_Com)
plot_boot <- data.frame(value = c(t(f3_boot_Pho_GQ[3, ]), t(f3_boot_Syn_GQ[3, ]), t(f3_boot_Com_GQ[3, ])), analysis = c(rep("Phonology", 500), rep("Morpho-syntax", 500), rep("Overall", 500)))
plot_data$analysis <- c("Phonology", "Morpho-syntax", "Overall")
plot <- ggplot(plot_data, aes(x = analysis)) +
  geom_violin(data = plot_boot, aes(x = analysis, y = value), alpha = 0.3, fill = "gray80", color = "gray30") + 
  # geom_segment(aes(xend = analysis, y = lower, yend = upper), 
  #              size = 1, color = "gray30") +
  geom_point(aes(y = f3), size = 3, stroke = 1, shape = 21, color = "black", fill = c("Pho"="#3868b8", "Syn"="#ebb840", "Com" = "#663C61")) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
  theme_minimal() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.title.x = element_text(margin = margin(t = 10)),
        panel.background = element_rect(fill = "gray95"),
        panel.border = element_rect(color = "black", fill = NA, size = 1),
        legend.position = "none",
        axis.text.y = element_text(color = c("black", "black"), size = 12)) + 
  scale_y_continuous(limits = c(-0.2, 0.2), breaks = c(-0.2, -0.1, 0, 0.1, 0.2)) +
  labs(y = expression(f[3]("Sn, Alt; GQ")), x = "", title = "") +
  coord_flip()
plot


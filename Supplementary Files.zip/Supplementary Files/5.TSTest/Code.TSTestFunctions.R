
#######################
### Load packages
#######################
library(dplyr)
library(tidyr)
library(purrr)
library(pbapply)
library(HDInterval)
library(ggplot2)
library(ggforce)
library(patchwork)
library(parallel)
library(stringi)
#######################


#######################
### Similarity comparison in triadic combination
#######################
sim_compar <- function(data, target, source_list) {
  pairs_num <- combn(source_list$num, 2, simplify = F)
  pairs_name <- combn(source_list$name, 2, simplify = F)
  agree_stat <- lapply(pairs_num, function(x) {
    a <- x[[1]]
    b <- x[[2]]
    list <- lapply(a, function(a) {
      lapply(b, function(b) {
        lapply(target, function(t) {
          sample <- data %>% slice(c(a, b, t)) %>% select_if(~ !any(. == "?"))
        })
      })
    })
    table <- {
      list.tidy.1 <- lapply(1:length(list), function(i) {
        lapply(1:length(list[[i]]), function(j) {
          bind <- do.call(cbind, list[[i]][[j]])
        })
      })
      list.tidy.2 <- lapply(1:length(list.tidy.1), function(i) {
        bind <- do.call(cbind, list.tidy.1[[i]])
      })
      do.call(cbind, list.tidy.2)
    } %>% t %>% as.data.frame()
    intersection_count <- table %>%
      unite(col = "intersection", sep = "") %>%
      group_by(intersection) %>%
      summarise(n = n()) %>%
      arrange(desc(n))
    count <- {
      countABA <- intersection_count %>% filter(intersection %in% c("101", "010")) %>% summarise(Total = sum(n)) %>% pull(Total)
      countABB <- intersection_count %>% filter(intersection %in% c("100", "011")) %>% summarise(Total = sum(n)) %>% pull(Total)
      countAAB <- intersection_count %>% filter(intersection %in% c("110", "001")) %>% summarise(Total = sum(n)) %>% pull(Total)
      c(countABA, countABB, countAAB)
    }
    rate <- {
      sum <- sum(count)
      rateABA <- count[1]/sum
      rateABB <- count[2]/sum
      rateAAB <- count[3]/sum
      c(rateABA, rateABB, rateAAB)
    }
    return(list(count = count, rate = rate))
  })
  pairs_name_vector <- lapply(pairs_name, function(x) {paste(x[[1]], x[[2]], sep = "-")}) %>% unlist
  names(agree_stat) <- pairs_name_vector
  return(agree_stat)
}
#######################


#######################
### Generate ramdon data
#######################
rand_data_gen <- function(N_rand, ref_data) {
  rand_data <- lapply(1:N_rand, function(i) {
    x <- lapply(1:nrow(ref_data), function(j) {
      sample(t(ref_data[j, ]), ncol(ref_data), replace = F)
    }) %>% do.call(rbind, .)
  })
  return(rand_data)
}
#######################


#######################
### HDI in triadic combination
#######################
paired_hdi <- function(empir_sc_result, rand_sc_result, source_list, credMass) {
  pairs_name_vector <- combn(source_list$name, 2, simplify = F) %>% lapply(., function(x) {paste(x[[1]], x[[2]], sep = "-")}) %>% unlist
  rand_value_list <- lapply(1:length(rand_sc_result[[1]]), function(i) {
    df <- as.data.frame(matrix(NA, nrow = length(rand_sc_result), ncol = length(rand_sc_result[[1]][[1]][["rate"]])))
    for(p in 1:ncol(df)) {
      for(q in 1:nrow(df)) {
        df[q, p] <- rand_sc_result[[q]][[i]][["rate"]][p]
      }
    }
    return(df)
  })
  rand_dens_list <- lapply(rand_value_list, function(x) {
    lapply(x, function(y) {
      dens <- density(y)
      df <- data.frame(val = dens$x, dens = dens$y)
    })
  })
  rand_hdi_list <- lapply(rand_value_list, function(x) {
    as.data.frame(apply(x, 2, function(y) {hdi(y, credMass = credMass)}))
  })
  rand_mean_list <- lapply(rand_value_list, function(x) {
    lapply(x, function(y) mean(y))
  })
  rand_md_list <- lapply(rand_value_list, function(x) {
    lapply(x, function(y) median(y))
  })
  names(rand_dens_list) <- pairs_name_vector
  names(rand_hdi_list) <- pairs_name_vector
  names(rand_mean_list) <- pairs_name_vector
  names(rand_md_list) <- pairs_name_vector
  result <- list(rand_dens_list = rand_dens_list, rand_hdi_list = rand_hdi_list, rand_mean_list = rand_mean_list, rand_md_list = rand_md_list)
  return(result)
}
#######################


#######################
### Plot permutation test in triadic combination
#######################
paired_hdi_plot <- function(paired_hdi_result, empir_sc_result, pair_name, target_name,
                            clr_curve = "gray20", clr_shade = "lightslategray", clr_empir_val = "pink", auto_clr_empir_val = T, clr_bar,
                            alpha = 0.2, line_type = "dashed", vert_size = 1) {
  plot_list <- lapply(1:3, function(mode) {
    hdi_lower <- paired_hdi_result$rand_hdi_list[[pair_name]][[mode]][1]
    hdi_upper <- paired_hdi_result$rand_hdi_list[[pair_name]][[mode]][2]
    vertical_line <- empir_sc_result[[pair_name]][["rate"]][mode]
    if(auto_clr_empir_val == T) {
      if(vertical_line > hdi_upper) clr_empir_val <- "#EC407A"
      else if (vertical_line < hdi_lower) clr_empir_val <- "#5C6BC0"
      else clr_empir_val <- "gray20"
    }
    df <- paired_hdi_result$rand_dens_list[[pair_name]][[mode]]
    plot <- ggplot(df, aes(x = val, y = dens)) +
      coord_cartesian(xlim = c(0, 1)) +
      geom_area(fill = clr_shade, alpha = alpha) +
      geom_area(data = subset(df, val >= hdi_lower & val <= hdi_upper), aes(x = val, y = dens), fill = clr_shade, alpha = 2 * alpha) +
      geom_line(color = clr_curve) +
      geom_vline(xintercept=vertical_line, color = clr_empir_val, linetype= line_type, size = vert_size) +
      labs(x = "Proportion",
           y = "Density") +
      theme_minimal() +
      theme(
        panel.grid = element_blank(),
        axis.line = element_line(color = "gray20")
      )
  })
  combined_plot <- plot_list[[1]] / plot_list[[2]] / plot_list[[3]] + plot_layout(ncol = 1, heights = c(1, 1, 1))
  return(combined_plot)
}
#######################


#######################
### Plot empirical stacked bar in triadic combination
#######################
sc_bar_plot <- function(empir_sc_result, pair_name, ref_vector, target_name,
                        clr1, clr2, clr3) {
  color_mapping <- setNames(c(clr1, clr2, clr3), ref_vector)
  bar_df <- data.frame(value = empir_sc_result[[pair_name]][["rate"]], ref = ref_vector)
  bar_df$ref <- factor(bar_df$ref, levels = ref_vector)
  bar <- ggplot(bar_df, aes(x = target_name, y = value, fill = ref)) +
    geom_bar(stat = "identity", position = "stack", color = "gray20") +
    scale_fill_manual(values = color_mapping) +
    labs(y = "Rate", x = "", fill = "Ref") +
    theme_minimal() +
    theme(
      panel.grid = element_blank()
    ) +
    coord_fixed(ratio = 10/1)
  bar
}
#######################


#######################
### z-score in triadic combination
#######################
paired_zscore <- function(empir_sc_result, rand_sc_result, source_list) {
  pairs_name_vector <- combn(source_list$name, 2, simplify = F) %>% lapply(., function(x) {paste(x[[1]], x[[2]], sep = "-")}) %>% unlist
  rand_mean_std_list <- lapply(1:length(rand_sc_result[[1]]), function(i) {
    df <- as.data.frame(matrix(NA, nrow = length(rand_sc_result), ncol = length(rand_sc_result[[1]][[1]][["rate"]])))
    for(p in 1:ncol(df)) {
      for(q in 1:nrow(df)) {
        df[q, p] <- rand_sc_result[[q]][[i]][["rate"]][p]
      }
    }
    mean <- colMeans(df)
    std <- apply(df, 2, sd)
    return(list(mean = mean, std = std))
  })
  zscore <- lapply(1:length(empir_sc_result), function(i) {
    lapply(1:length(empir_sc_result[[1]][["rate"]]), function(j) {
      (empir_sc_result[[i]][["rate"]][[j]] - rand_mean_std_list[[i]][["mean"]][[j]])/rand_mean_std_list[[i]][["std"]][[j]]
    }) %>% unlist
  })
  names(zscore) <- pairs_name_vector
  return(zscore)
}
#######################


#######################
### Summerize global z-score
#######################
sum_zscore <- function(source_list, empir_s_c_result, paired_hdi_result, paired_zscore_result, use_threshold = "hdi_upper") {
  z_signi_list <- lapply(names(empir_s_c_result), function(x) {
    lapply(1:3, function(i) {
      empir_rate <- empir_s_c_result[[x]][["rate"]][i]
      hdi_upper <- paired_hdi_result[["rand_hdi_list"]][[x]][[i]][2]
      mean <- paired_hdi_result[["rand_mean_list"]][[x]][[i]]
      md <- paired_hdi_result[["rand_md_list"]][[x]][[i]]
      if(use_threshold == "hdi_upper") {
        if(empir_rate > hdi_upper) x <- paired_zscore_result[[x]][i]
        else x <- 0
      } else
        if(use_threshold == "mean") {
          if(empir_rate > mean) x <- paired_zscore_result[[x]][i]
          else x <- 0
        } else
          if (use_threshold == "md") {
            if(empir_rate > md) x <- paired_zscore_result[[x]][i]
            else x <- 0
          }
    })
  })
  names(z_signi_list) <- names(empir_s_c_result)
  
  pairs_name <- combn(source_list$name, 2, simplify = F)
  name_vector_source <- lapply(pairs_name, unlist) %>% unlist
  name_vector_source_and_target <- c(name_vector_source, rep("tar", length(name_vector_source)/2))
  rate_vector_source <- lapply(z_signi_list, function(x) {x[1:2]}) %>% unlist
  rate_vector_source_and_traget <- c(rate_vector_source, lapply(z_signi_list, function(x) {x[3]}) %>% unlist)
  df <- data.frame(label = name_vector_source_and_target, rate = rate_vector_source_and_traget)
  cat_sum <- aggregate(rate ~ label, data = df, sum)
  cat_sum_average <- cat_sum %>% mutate(., rate_aver = rate/(length(rate_vector_source)/length(source_list$name)))
  
  return(cat_sum_average)
}
#######################



#######################
### Summarize global scores
#######################
sum_rate <- function(source_list, empir_s_c_result) {
  rate_list <- lapply(names(empir_s_c_result), function(x) {
    lapply(1:3, function(i) {
      empir_rate <- empir_s_c_result[[x]][["rate"]][i]
    })
  })
  names(rate_list) <- names(empir_s_c_result)
  pairs_name <- combn(source_list$name, 2, simplify = F)
  name_vector_source <- lapply(pairs_name, unlist) %>% unlist
  name_vector_source_and_target <- c(name_vector_source, rep("tar", length(name_vector_source)/2))
  rate_vector_source <- lapply(rate_list, function(x) {x[1:2]}) %>% unlist
  rate_vector_source_and_traget <- c(rate_vector_source, lapply(rate_list, function(x) {x[3]}) %>% unlist)
  df <- data.frame(label = name_vector_source_and_target, rate = rate_vector_source_and_traget)
  cat_sum <- aggregate(rate ~ label, data = df, sum)
  cat_sum_average <- cat_sum %>% mutate(., rate_aver = rate/(length(rate_vector_source)/length(source_list$name)))
  cat_sum_average_norm <- cat_sum_average %>% mutate(., rate_aver_norm = rate_aver/sum(rate_aver))
  return(cat_sum_average_norm)
}
#######################


#######################
### Plot circles
#######################
circles_plot <- function(sum_zscore_result, target_name) {
  non_tar <- which(sum_zscore_result$label != "tar")
  n <- nrow(sum_zscore_result)-1
  radius_outer <- 0.5
  radius_center <- 0.6
  distance <- 1.5
  arrow_labels <- sum_zscore_result$rate_aver_norm[non_tar] %>% round(digits = 2)
  unique_value <- sum_zscore_result$rate_aver_norm[which(sum_zscore_result$label == "tar")] %>% round(digits = 2)
  arrow_thickness <- (arrow_labels / max(arrow_labels)) * 2
  theta <- seq(0, 2*pi, length.out = n+1)[-1]
  x_outer <- cos(theta) * distance
  y_outer <- sin(theta) * distance
  x_end <- cos(theta) * radius_center
  y_end <- sin(theta) * radius_center
  circles <- data.frame(
    x = c(x_outer, 0),
    y = c(y_outer, 0),
    label = c(sum_zscore_result$label[non_tar], target_name),
    radius = c(rep(radius_outer, n), radius_center)
  )
  arrows <- data.frame(
    x_start = x_outer - cos(theta) * radius_outer,
    y_start = y_outer - sin(theta) * radius_outer,
    x_end = x_end,
    y_end = y_end,
    label = arrow_labels,
    thickness = arrow_thickness
  )
  arrows <- arrows[arrows$label != 0, ]
  plot <- ggplot() +
    geom_circle(aes(x0 = x, y0 = y, r = radius), data = circles, 
                color = "gray40", size = 1.5) +
    geom_text(aes(x = x, y = y, label = label), data = circles, vjust = 0.35, size = 5, fontface = "bold") +
    geom_segment(aes(x = x_start, y = y_start, xend = x_end, yend = y_end, size = thickness), 
                 data = arrows, color = "gray40") +
    geom_text(aes(x = (x_start + x_end)/2, y = (y_start + y_end)/2, label = label), 
              data = arrows, vjust = -0.3, color = "black", size = 5) +
    coord_fixed() +
    theme_void() +
    theme(legend.position = "none") +
    scale_size(range = c(0.5, 2))
  if(unique_value != 0) {
    plot <- plot +
      geom_text(aes(x = 0, y = -radius_center + 0.3, label = paste("Unique:", unique_value)), 
                size = 4, color = "black", vjust = 0)
  }
  return(plot)
}
#######################



#######################
### Main analysis
#######################
run.analysis <- function(data, N_rand, target, source_list, target_name, clr1, clr2, clr3, value = "prop", credMass = 0.95, use_threshold = "hdi_upper") {
  ### Generate random data
  rand_data_result <- rand_data_gen(N_rand, ref_data = data[-1])
  ### Trait sharing comparison，empirical
  emp_s_c <- sim_compar(data = data[-1], target = target, source_list = source_list)
  ### Merge random data into real data
  source_list_index <- do.call(c, source_list$num)
  sour_rand <- lapply(1:length(rand_data_result), function(i) {
    x <- rand_data_result[[i]] %>% as.data.frame()
    x[source_list_index, ] <- data[source_list_index, -1]
    x
  })
  ### Trait sharing comparison，random
  cl <- makeCluster(detectCores()-1)
  clusterEvalQ(cl, {
    library(dplyr)
    library(tidyr)
    library(purrr)
    library(pbapply)
    library(HDInterval)
    library(ggplot2)
    library(patchwork)
  })
  clusterExport(cl, varlist = c("sim_compar"))
  rand_s_c <- pblapply(sour_rand, function(x) {
    sim_compar(data = x, target = target, source_list = source_list)
  }, cl = cl)
  stopCluster(cl)
  ### HDI in triadic combination
  paired_hdi_result <- paired_hdi(empir_sc_result = emp_s_c, rand_sc_result = rand_s_c, source_list = source_list, credMass = credMass)
  ### Plot HDI in triadic combination
  pair_name_vector <- names(paired_hdi_result$rand_hdi_list)
  plot_hdi_list <- lapply(pair_name_vector, function(x) {
    plot_hdi <- paired_hdi_plot(paired_hdi_result = paired_hdi_result, empir_sc_result = emp_s_c, pair_name = x)
    ref_vector <- strsplit(x, "-") %>% unlist() %>% c(., "Unique")
    bar <- sc_bar_plot(empir_sc_result = emp_s_c, pair_name = x, ref_vector = ref_vector, target_name = target_name,
                       clr1 = clr1, clr2 = clr2, clr3 = clr3); bar
    plot <- plot_hdi | bar + plot_layout(widths=c(3,1)); plot
  })
  names(plot_hdi_list) <- pair_name_vector
  ### Summarize global scores, empirical
  if(value == "prop") {
    sum_rate_result <- sum_rate(source_list = source_list, empir_s_c_result = emp_s_c)
  } else
  if(value == "z") {
    paired_zscore_result <- paired_zscore(empir_sc_result = emp_s_c, rand_sc_result = rand_s_c, source_list = source_list)
    sum_zscore_result <- sum_zscore(source_list = source_list, empir_s_c_result = emp_s_c, paired_hdi_result = paired_hdi_result, paired_zscore_result = paired_zscore_result, use_threshold = use_threshold)
  }
  ### Summarize global scores, random
    ## This part is not applicable to the "z-score" mode
  if(value == "prop") {
    sum_rate_result_rand <- lapply(rand_s_c, function(x) sum_rate(source_list = source_list, empir_s_c_result = x))
    sum_rate_result_rand_rate_aver_norm <- lapply(sum_rate_result_rand, function(x) x[["rate_aver_norm"]]) %>% do.call(rbind, .) %>% as.data.frame()
    colnames(sum_rate_result_rand_rate_aver_norm) <- sum_rate_result$label
    sorted_col <- c(setdiff(sort(names(sum_rate_result_rand_rate_aver_norm)), "tar"), "tar")
    sum_rate_result_rand_rate_aver_norm <- sum_rate_result_rand_rate_aver_norm[ , sorted_col]
    remove("sum_rate_result_rand")
    ### Generate  95% HDI for rate_aver_norm of random data
    sum_rate_result_rand_rate_aver_norm_hdi_list <- lapply(sum_rate_result_rand_rate_aver_norm, function(x) {
      hdi(x, credMass = credMass)
    })
    sum_rate_result_rand_rate_aver_norm_hdi_table <- do.call(rbind, sum_rate_result_rand_rate_aver_norm_hdi_list) %>% cbind(label = rownames(.), .) %>% as.data.frame()
    remove("sum_rate_result_rand_rate_aver_norm_hdi_list")
    ### Judge if empirical values fall within the 95% HDI
    merged_df <- merge(sum_rate_result, sum_rate_result_rand_rate_aver_norm_hdi_table, by = "label")
    merged_df$flag <- ifelse(merged_df$rate_aver_norm > merged_df$upper, 1,
                             ifelse(merged_df$rate >= merged_df$lower, 0, -1))
    is_rate_signi <- merged_df[c("label", "flag")]
    remove("merged_df")
    ### Stacked kernel density
    n <- ncol(sum_rate_result_rand_rate_aver_norm)
    stack_sum_rate_result_rand_rate_aver_norm <- as.data.frame(t(apply(sum_rate_result_rand_rate_aver_norm, 1, function(row) {
      sapply(1:(ncol(sum_rate_result_rand_rate_aver_norm)-1), function(i) {
        if (i <= n) {
          sum(row[1:i])
        } else {
          NA
        }
      })
    })))
    colnames(stack_sum_rate_result_rand_rate_aver_norm) <- paste0("Stack", 1:(ncol(sum_rate_result_rand_rate_aver_norm)-1))
    ### Plot
    ## Circles
    circles_plot_result <- circles_plot(sum_zscore_result = sum_rate_result, target_name = target_name); circles_plot_result
    ## Kernel density for random scores
    density_plot_data <- stack_sum_rate_result_rand_rate_aver_norm %>%
      pivot_longer(
        cols = everything(),
        names_to = "Group",
        values_to = "Value"
      )
    d_p <- ggplot(density_plot_data, aes(x = Value, fill = Group)) +
      geom_density(alpha = 0.5) +
      labs(title = target_name,
           subtitle = paste0("Density plot by randomization"),
           x = "",
           y = "Density") +
      theme_minimal() +
      scale_x_continuous(limits = c(0, 1), breaks = c(0.00, 0.25, 0.50, 0.75, 1.00)) +
      scale_fill_brewer(palette = "Set1", labels = sorted_col) +
      theme(legend.position = "none")
    ## Stacked bar for emipiral scores
    stack_plot_data <- sum_rate_result
    stack_plot_data$label <- factor(stack_plot_data$label, levels = sorted_col[length(sorted_col):1])
    stack_plot_data <- arrange(stack_plot_data, desc(label))
    stack_plot_data <- stack_plot_data %>% mutate(cumsum = cumsum(rate_aver_norm), mid = cumsum - 0.5*rate_aver_norm)
    stack_plot_data <- merge(stack_plot_data, is_rate_signi, by = "label")
    s_p <- ggplot(stack_plot_data, aes(y = "", x = rate_aver_norm, fill = label)) +
      geom_bar(stat = "identity", alpha = 0.5, color = "black") +
      geom_text(data = stack_plot_data[stack_plot_data$flag == 1, ], aes(x = mid, label = "*", y = 0.75), size = 8) +
      scale_fill_brewer(palette = "Set1", direction = -1) +
      labs(subtitle = "Bar chart of real proportions", x = "Proportion", y = "") +
      theme_minimal() +
      theme(legend.position = "bottom") +
      scale_x_continuous(limits = c(0, 1), breaks = c(0.00, 0.25, 0.50, 0.75, 1.00)) +
      labs(fill = "Source")
    ## Combine plots
    combined_plot <- d_p / s_p +
      plot_layout(heights = c(8, 1))
    combined_plot
  } else
  if(value == "z") {
    circles_plot_result <- circles_plot(sum_zscore_result = sum_zscore_result, target_name = target_name); circles_plot_result
  }
  if(value == "prop") {
    return_list <- list(paired_hdi_result = paired_hdi_result, 
                        sum_rate_result = sum_rate_result,
                        sum_rate_result_rand_rate_aver_norm = sum_rate_result_rand_rate_aver_norm,
                        sum_rate_result_rand_rate_aver_norm_hdi_table = sum_rate_result_rand_rate_aver_norm_hdi_table,
                        is_rate_signi = is_rate_signi,
                        plot_hdi_list = plot_hdi_list, 
                        circles_plot_result = circles_plot_result, 
                        densi_bar_plot_result = combined_plot,
                        target_name = target_name)
  } else
  if(value == "z") {
    return_list <- list(paired_hdi_result = paired_hdi_result, 
                        paired_zscore_result = paired_zscore_result, 
                        sum_zscore_result = sum_zscore_result,  
                        plot_hdi_list = plot_hdi_list, 
                        circles_plot_result = circles_plot_result, 
                        target_name = target_name)
  }
  return(return_list)
}
####################### 
  
  
#######################
### Save plots and tables
#######################
save_plots_and_tables <- function(analysis_result, dir, value = "prop"){
  folder_path <- file.path(dir, paste0("analysis_plot_", analysis_result$target_name, Sys.Date()))
  if(!dir.exists(folder_path)) {
    dir.create(folder_path)
  }
  for(i in 1:length(analysis_result$plot_hdi_list)){
    ggsave(filename = paste0(folder_path, "/", analysis_result$target_name, "_", names(analysis_result$plot_hdi_list)[i], Sys.Date(), ".pdf"), analysis_result$plot_hdi_list[[i]])
  }
  if(value == "z"){
    zscore_name <- analysis_result$sum_zscore_result$label[which(analysis_result$sum_zscore_result$label != "tar")] %>% paste0(collapse = "")
    ggsave(filename = paste0(folder_path, "/", analysis_result$target_name, "_", zscore_name, "_circles_plot", Sys.Date(), ".pdf"), analysis_result$circles_plot_result)
  } else
  if(value == "prop"){
    rate_name <- analysis_result$sum_rate_result$label[which(analysis_result$sum_rate_result$label != "tar")] %>% paste0(collapse = "")
    ggsave(filename = paste0(folder_path, "/", analysis_result$target_name, "_", rate_name, "_circles_plot", Sys.Date(), ".pdf"), analysis_result$circles_plot_result)
    ggsave(filename = paste0(folder_path, "/", analysis_result$target_name, "_", rate_name, "_densi_bar_plot", Sys.Date(), ".pdf"), analysis_result$densi_bar_plot_result)
  }
  folder_path_table <- file.path(dir, paste0("/analysis_table_", analysis_result$target_name, Sys.Date()))
  if(!dir.exists(folder_path_table)) {
    dir.create(folder_path_table)
  }
  # paired_hdi_result_table <- as.data.frame(analysis_result$paired_hdi_result)
  # write.csv(paired_hdi_result_table, paste0(folder_path_table, "/", analysis_result$target_name, "_paired_hdi_result", Sys.Date(), ".csv"))
  if(value == "z") {
    paired_zscore_result_table <- as.data.frame(analysis_result$paired_zscore_result)
    write.csv(paired_zscore_result_table, paste0(folder_path_table, "/", analysis_result$target_name, "_paired_zscore_result", Sys.Date(), ".csv"))
    write.csv(analysis_result$sum_zscore_result, paste0(folder_path_table, "/", analysis_result$target_name, "_sum_zscore_result", Sys.Date(), ".csv"))
  } else
  if(value == "prop") {
    write.csv(analysis_result$sum_rate_result, paste0(folder_path_table, "/", analysis_result$target_name, "_sum_rate_result", Sys.Date(), ".csv"))
    write.csv(analysis_result$sum_rate_result_rand_rate_aver_norm, paste0(folder_path_table, "/", analysis_result$target_name, "_sum_rate_result_rand_rate_aver_norm", Sys.Date(), ".csv"))
    write.csv(analysis_result$sum_rate_result_rand_rate_aver_norm_hdi_table, paste0(folder_path_table, "/", analysis_result$target_name, "_sum_rate_result_rand_rate_aver_norm_hdi_table", Sys.Date(), ".csv"))
    write.csv(analysis_result$is_rate_signi, paste0(folder_path_table, "/", analysis_result$target_name, "_is_rate_signi", Sys.Date(), ".csv"))
    }
  }
  #######################




